export default {
  secret: '788afefe9617af8f7f72c9be3afba7c7',
  expiresIn: '7d'
}
